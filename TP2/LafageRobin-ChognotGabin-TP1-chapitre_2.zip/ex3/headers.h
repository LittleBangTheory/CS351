int quotient(int, int);
int reste(int, int);
int valeurAbsolue(int);
int ppcm(int, int);
int pgcd(int, int);
int puissance(int, int);
int sommeDesImpairs(int, int);
int estUneDecompositionDe(int, int);
void testBibliotheque();
