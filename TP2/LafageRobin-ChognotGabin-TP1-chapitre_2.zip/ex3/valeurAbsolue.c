#include <stdio.h>
#include <stdlib.h>

int valeurAbsolue(int a) {
  return abs(a);
}
