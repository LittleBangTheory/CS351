void dessineCarre(int, int, int);
void dessineCarreDiagonale(int, int, int);
void dessineMosaique(int, int, int, int, int);
void dessineMosaiqueAvecSouris(int, int, int);
