void afficherNotes(float[], int);
float minimumNote(float[], int);
float maximumNote(float[], int);
float calculMoyenne(float[], int);
float calculVariance(float[], int);
float calculEcartType(float[], int);
int rechercherValeur(float[], int, float);
