int lireDonnees(char[], int[]);
void afficherTableau(int[], int);
void triABulles(int[], int);
void swap(int[], int[]);
void enregisterDonnees(char[], int[], int);
