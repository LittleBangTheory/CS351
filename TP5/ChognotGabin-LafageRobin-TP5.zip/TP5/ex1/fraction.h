typedef struct {
int num ; /* numérateur */
int den ; /* dénominateur */
} Fraction ;

int pgcd(int, int);
void addFraction(Fraction, Fraction);
void subFraction(Fraction, Fraction);
void mulFraction(Fraction, Fraction);
void divFraction(Fraction, Fraction);
